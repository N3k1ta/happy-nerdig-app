

import CreateForm from "./CreateForm"

export default function CreateModule() {
  return (
    <main>
      <h2>Create Module</h2>
      <CreateForm />
    </main>

  )
}
